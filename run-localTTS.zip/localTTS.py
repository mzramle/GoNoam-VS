import os
import json
import gradio as gr
from flask import Flask, request, jsonify, send_file
from assets.i18n.i18n import I18nAuto

from flask_cors import CORS
from core import (
    run_tts_script,
)

from rvc.infer.infer import VoiceConverter

i18n = I18nAuto()

app = Flask(__name__)
CORS(app)

now_dir = os.getcwd()
model_root = os.path.join(now_dir, "logs")
index_root = os.path.join(now_dir, "indexes")

model_root_relative = os.path.relpath("models")
index_root_relative = os.path.relpath("indexes")

current_script_directory = os.path.dirname(os.path.realpath(__file__))
MODEL_DIR = os.path.join(current_script_directory, "models")
INDEX_DIR = os.path.join(current_script_directory, "indexes")

custom_embedder_root = os.path.join(now_dir, "rvc", "embedders", "embedders_custom")
os.makedirs(custom_embedder_root, exist_ok=True)

def get_files_by_extension(root_dir, extensions):
    return [
        os.path.join(root, file)
        for root, _, files in os.walk(root_dir, topdown=False)
        for file in files
        if any(file.endswith(ext) for ext in extensions)
    ]

model_files = get_files_by_extension(model_root, [".pth", ".onnx"])
index_files = get_files_by_extension(model_root, [".index"])

with open(os.path.join(now_dir, "rvc", "lib", "tools", "tts_voices.json"), "r") as file:
    tts_voices_data = json.load(file)
    short_names = [voice.get("ShortName", "") for voice in tts_voices_data]

@app.route('/models', methods=['GET'])
def get_models():
    models_list = [
        os.path.join(dirpath, filename)
        for dirpath, _, filenames in os.walk(model_root_relative)
        for filename in filenames
        if filename.endswith(".pth")
    ]
    return jsonify(models_list if models_list else "")

@app.route('/indexes', methods=['GET'])
def get_indexes():
    indexes_list = [
        os.path.join(dirpath, filename)
        for dirpath, _, filenames in os.walk(index_root_relative)
        for filename in filenames
        if filename.endswith(".index") and "trained" not in filename
    ]
    return jsonify(indexes_list if indexes_list else "")

@app.route('/voices', methods=['GET'])
def get_voices():
    json_path = os.path.join("rvc", "lib", "tools", "tts_voices.json")
    with open(json_path, "r") as file:
        tts_voices_data = json.load(file)
    
    voices = [
        {
            "ShortName": voice.get("ShortName", ""),
            "Gender": voice.get("Gender", "")
        }
        for voice in tts_voices_data
    ]
    return jsonify({'voices': voices})
@app.route('/tts', methods=['POST'])
def tts():
    data = request.json
    tts_text = data.get('tts_text')
    tts_voice = data.get('tts_voice')
    tts_rate = data.get('tts_rate')
    pitch = data.get('pitch')
    filter_radius = data.get('filter_radius')
    index_rate = data.get('index_rate')
    rms_mix_rate = data.get('rms_mix_rate')
    protect = data.get('protect')
    hop_length = data.get('hop_length')
    f0method = data.get('f0method')
    outputn = data.get('output_tts_path')
    output_tts_path = os.path.join(now_dir, "assets", "audios", "tts_output.wav")
    output_rvc_path = os.path.join(now_dir, "assets", "audios", "tts_rvc_output.wav")
    model_file = data.get('model_file')
    index_file = data.get('index_file')
    split_audio = data.get('split_audio')
    autotune = data.get('autotune')
    clean_audio = data.get('clean_audio')
    clean_strength = data.get('clean_strength')
    export_format = data.get('export_format')
    embedder_model = data.get('embedder_model')
    embedder_model_custom = data.get('embedder_model_custom')
    upscale_audio = data.get('upscale_audio')
    f0_file = gr.File(
                label=i18n(
                    "The f0 curve represents the variations in the base frequency of a voice over time, showing how pitch rises and falls."
                ),
                visible=True,
            )

    run_tts_script(
        tts_text,
        tts_voice,
        tts_rate,
        pitch,
        filter_radius,
        index_rate,
        rms_mix_rate,
        protect,
        hop_length,
        f0method,
        output_tts_path,
        output_rvc_path,
        model_file,
        index_file,
        split_audio,
        autotune,
        clean_audio,
        clean_strength,
        export_format,
        embedder_model,
        embedder_model_custom,
        upscale_audio,
        f0_file,
    )

    print("Pitch Extraction Algorithm: ", f0method)
    return send_file(output_rvc_path, as_attachment=True, download_name=f"{outputn}.wav")

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
